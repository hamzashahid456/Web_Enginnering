<footer>
       <p> Copyright (c) 2023, All rights reserved.</p>
</footer>