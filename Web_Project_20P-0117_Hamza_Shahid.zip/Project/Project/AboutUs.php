<?php include 'inc/header.php'; ?>

<style>
	/* body {
		background-color: #333;
		color: #fff;
		font-family: Arial, sans-serif;
		margin: 0;
		padding: 0;
	}

	.container {
		max-width: 960px;
		margin: 0 auto;
		padding: 50px;
	} */

	p {
		font-size: 24px;
		line-height: 1.5;
		margin-bottom: 20px;
	}

	a {
		color: #fff;
	}
</style>
<body>
	<main>
		<section class="content">
			<center><h2>About Us</h2></center>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi sit amet neque diam. Integer ultricies eget lorem eu pulvinar. Integer congue, mi ac suscipit feugiat, turpis quam gravida lorem, at auctor leo risus vel felis. Praesent in justo in turpis dignissim dapibus. Donec dignissim diam sed enim pharetra, vel iaculis risus blandit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec sit amet metus lobortis, luctus elit nec, varius velit. Aliquam lacinia, quam sed bibendum tristique, tortor quam placerat mi, a eleifend justo purus ac neque. Sed commodo laoreet sapien vel bibendum. Nam commodo auctor gravida.</p>
			<p>Sed vulputate libero velit, in tincidunt sapien convallis sit amet. Nulla facilisi. Sed vitae tincidunt nulla. Suspendisse potenti. Fusce luctus dolor in odio sagittis congue. Donec quis metus ac nisl rhoncus convallis. Etiam ut velit eu metus ullamcorper varius at at elit. Ut nec eros elit. Sed posuere eget mi ut euismod. In euismod a mauris ut posuere. Duis semper purus id mollis eleifend.</p>
		</section>
	</main>

	<footer>
		<?php include 'inc/footer.php'; ?>
	</footer>
</body>
</html>


