<?php
  include 'inc/header.php';  
?>

<body>
    <h1>Please Login first!</h1>
</body>

</html>