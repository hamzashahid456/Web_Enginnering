Task Completed

Made changes in index.html by applying css file located in CSS folder

Made changes in login.html by applying css file located in CSS folder
